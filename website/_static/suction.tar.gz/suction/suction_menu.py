﻿#!/usr/bin/env pyformex

# pyFormex Suction Menu

#
#  Copyright (C) 2013
#  Tomas Praet (tomas.praet@telenet.be),
#  Benedict Verhegghe (benedict.verhegghe@ugent.be),
#  Anabela Maia (anabelamaia@gmail.com),
#  Dominique Adriaens (dominique.adriaens@ugent.be),
#
#  Distributed under the GNU General Public License version 3 or later.
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see http://www.gnu.org/licenses/.
#

"""
.. Description

=======================================
pyFormex menu for the suction model
=======================================

This menu allows you to create a model of a fish head based on the coordinates of certain reference points (measured on CT scans).
This model can than rotate around certain (physical) axes, after which the influence on the internal volume can be calculated and visualised.
In this way research can be done on how the head of fish that use suction feeding is adapted through evolution
to create an efficient internal volume change of their mouth (and thus fast suction feeding).

By convention all angles are defined in such a way that a positive value corresponds to
an increase in internal volume (for realistic models and angles), and vice versa.

The input comes from a .csv file that contains the 3D pixel values of the reference points.
The reference points in this file should be ordened like this (each line of the file should have 3 pixel coordinates separated by ';'):

1. Hyomandibula caudal articulation (left)
2. Palatine rostral tip (left)
3. Premaxillary rostral tip
4. Mandibular articulation (left)
5. Preopercle lower tip (left)
6. Opercle caudodorsal tip (left)
7. Hyomandibula caudal articulation (right)
8. Palatine rostral tip (right)
9. Hyoid symphysis
10. Maxillary-Dentary joint (left)

Within pyFormex the geometry is saved based on 9 basepoints:

0. Hyomandibula caudal articulation (right)
1. Palatine rostral tip (right)
2. Premaxillary rostral tip
3. Mandibular articulation (right)
4. Preopercle lower tip (right)
5. Opercle caudodorsal tip (right)
6. Hyoid symphysis
7. Lower jaw tip
8. Maxillary-dentary joint

Before jaw rotation basepoint 2 and 7 might be exactly the same.
The basepoints can manually be inserted or adjusted.
Be careful when doing so though, because the definition of these basepoints is very strict!
Some automatic checking is added to help you chose valid values, but is not infallible.

Applying rotations to the model will result in changes in the basepoint coordinates,
after which the geometry will be re-build.
Should you want to reset the basepoints to an older model,
you can select the model and use 'Extract basepoints from the current model'.

When running the script the first time, an example is run that first loads an example geometry and
subsequently uses example kinematic data to generate example results.

Created by Tomas Praet, under supervision of professor Dominique Adriaens and professor Benedict Verhegghe.
"""

from numpy import *
from plugins.trisurface import *
from formex import *
from plugins.surface_menu import *
from plugins.curve import *
from plugins import surface_menu
import sys
import odict
import os
from gui.widgets import simpleInputItem as I,tabInputItem as T
import gui.image as image
from scipy.optimize import curve_fit
import Gnuplot   #Uncomment to show plots using gnuplot.py

# Main function of the script _______________________________________

def rotatefile():
    """Rotate the jaw, hyoid, and suspensorium based on kinematic data saved in a .csv file."""

    global basepoints, res

    if len(basepoints)==0:
        warning('You must first create a model!')
        suction()                           # If the model of the fish head is not yet created, start the model creation function

    currentDir = os.getcwd()                # This is the work directory
    resultdir = currentDir+'/results/'      # Directory in which the output is saved
    animdir = currentDir+'/animations/'     # Directory in which the animations are saved
    name = 'example'                        # The name of the current model
    totalPoints = 200                       # The number of interpolation points that will be used in resampling the input
    anim = False                            # Whether the resulting animation of the fish head should be saved
    fn = currentDir+'/input/example.csv'    # File containing the time in the first column and the gape, hyoid, and suspensorium angles in the next columns
    cutting = False                         # Whether a cut should be created to get volumechanges of only a certain part of the fish head
    perc = 50.                              # Percentage of the head that should be cut if cutting is True
    plotting = False                        # Whether to show the resulting graphs (Gnuplot should be installed and uncommented above)
    smoothiter = 20                         # The number of smoothing iterations that should be imposed on the data to avoid unrealistic results in the derivatives

    # Ask for the script parameters with a menu
    res = askItems(
        caption='Calculate volumes and speeds',
        items=[
            _I('fn',fn,buttons=[('Select File',selectFile)],text='File containing angles'),
            _I('name', name, text='Name of export files'),
            _I('totalPoints', totalPoints, text='Number of time points'),
            _I('anim', anim, text='Create an animation'),
            _I('cutting', cutting, text='Make plots at a cross-section'),
            _I('perc', perc, text='Percentage of where to take the cross-section'),
            _I('plotting', plotting, text='Create plots in the output'),
            _I('smoothiter', smoothiter, text='Smoothing iterations'),
        ], enablers=[
            ('cutting', True, 'perc'),
        ], )
    if not res:
        return
    globals().update(res)
    fn, name, totalPoints, anim, perc, cutting, plotting, smoothiter = res['fn'], res['name'], res['totalPoints'], res['anim'], res['perc'], res['cutting'], res['plotting'], res['smoothiter']

    if anim:
        nameseq = utils.NameSequence(export,'.png')

    export = animdir+name
    exportcsv = resultdir+name+'.csv'

    # Reading the curves
    fil = file(fn,'r')
    le = len(fil.readlines())-1
    fil.seek(0)
    header = fil.readline()
    points = ndarray([0,0])
    for i in range(le):
        points = append(points,fromfile(fil,dtype=float,count=4,sep=','))
    points = points.reshape(-1,4)
    time = points[:, 0]*100.
    gape = asarray([time, points[:, 1]]).transpose()
    hyoid = asarray([time, points[:, 2]]).transpose()
    susp = asarray([time, points[:, 3]]).transpose()
    gape = subdivideAndSmooth(gape, totalPoints, smooth=smoothiter)
    hyoid = subdivideAndSmooth(hyoid, totalPoints, smooth=smoothiter)
    susp = subdivideAndSmooth(susp, totalPoints, smooth=smoothiter)
    points = asarray([gape[:, 0]/100., gape[:, 1], hyoid[:, 1], susp[:, 1]]).transpose().reshape(-1, 4)
    le = len(points[:, 0])
    clear()
    vol, time, area = empty(le), empty(le), empty(le)
    gape, depr, suspens = empty(le), empty(le), empty(le)
    model0,Pnew0,area0 = fill(basepoints)
    DR = draw(model0)
    DRT = drawText('Time: initial', 20, 10)
    if cutting:
        volPart, areaPart = empty(le), empty(le)
        b = model0.bbox()
        cutx = b[0, 0] + perc / 100. * (b[1, 0]-b[0, 0])
    for i, step in enumerate(points):
        time[i] = step[0]
        newPoints = rotateall(basepoints, [step[1], step[2], step[3], 0.])
        result = fill(newPoints)
        vol[i] = result[0].toSurface().volume()
        newPointsClosed = Coords([newPoints[0],newPoints[1],newPoints[2],newPoints[3],newPoints[4],newPoints[5],newPoints[6],newPoints[2],newPoints[8]])
        area[i] = result[2]-fill(newPointsClosed)[2]
        gape[i] = newPoints[2][1]-newPoints[7][1]
        depr[i] = newPoints[6][1]
        suspens[i] = 2*newPoints[3][2]
        dr = draw(result[0], bbox='last')                           # Draw the model
        drt = drawText('Time: %5.3f s' % step[0], 20, 10)
        undraw(DR)
        undraw(DRT)
        DR = dr
        DRT = drt
        if anim:
            image.save_canvas(pf.canvas,nameseq.next(),fmt='png')   # Save the screen to create the animation
        if cutting:
            S, A = cutModel(result[0].toSurface(), cutX=cutx)
            volPart[i] = S.volume()
            areaPart[i] = A

    # 10th-degree approximation of this function
    volapprox, cov = curve_fit(func, time, vol)
    areaapprox, cov = curve_fit(func, time, area)
    vol = degree10(time, volapprox)
    area = degree10(time, areaapprox)
    volchange = deriv1degree10(time,volapprox)
    volchangeapprox, cov = curve_fit(func, time, volchange)
    speed = divide(volchange,area)
    speedapprox,cov = curve_fit(func, time, speed)
    #speed = degree10(time, speedapprox)
    accel = deriv1degree10(time,speedapprox)

    d = time[1] - time[0]

    #volchange = (vol-append(vol[0], vol[0:-1]))/d
    #speed = divide(volchange,area)
    #accel = (speed-append(speed[0], speed[0:-1]))/d
    #half = len(speed)/2
    #maxspeed = max(speed[:half])
    #message('Maximum intake speed: %s' % maxspeed)
    #message('Time of maximum intake speed: %s' % time[where(speed==maxspeed)[0]])

    rdict = odict.ODict({})      # Create a dictionary containing the results
    rdict['Time'] = time
    rdict['Gape'] = points[:, 1]
    rdict['Hyoid'] = points[:, 2]
    rdict['Suspensorium'] = points[:, 3]
    rdict['Volume'] = vol
    rdict['Area'] = area
    rdict['Volume Change'] = volchange
    rdict['Volume Change Relative'] = divide(volchange, vol)
    rdict['Average speed at aperture'] = speed
    rdict['Average acceleration at aperture'] = accel
    rdict['Gape distance'] = gape
    rdict['Hyoid depression'] = depr
    rdict['Suspensorium expansion'] = suspens

    if plotting:
        import Gnuplot
        g=Gnuplot.Gnuplot(persist=1)
        g.plotcmd = 'plot'
        g._clear_queue()
        g.xlabel('Time [s]')
        # Plotting the volume
        g.ylabel('Volume [mm3]')
        g.title('Buccal internal volume')
        g._add_to_queue([Gnuplot.Data(time,vol,title='Volume',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_volume.eps' , color=True, solid=True)
        g._clear_queue()
        # Plotting the angles
        g.ylabel('Angle [degrees]')
        g.title('Gape angles')
        g._add_to_queue([Gnuplot.Data(time,points[:, 1],title='Gape',with_='lines')])
        g._add_to_queue([Gnuplot.Data(time,points[:, 2],title='Hyoid',with_='lines')])
        g._add_to_queue([Gnuplot.Data(time,points[:, 3],title='Suspensorium',with_='lines')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_angles.eps', color=True, solid=True)
        g._clear_queue()
        # Plotting the volume change
        g.ylabel('Volume change [mm3/s]')
        g.title('Rate of change of the internal volume')
        g._add_to_queue([Gnuplot.Data(time,volchange,title='Volume change',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_volumeChange.eps', color=True, solid=True)
        g._clear_queue()
        # Plotting the relative volume change
        g.ylabel('Relative volume change [%]')
        g.title('Relative rate of change of the internal volume')
        g._add_to_queue([Gnuplot.Data(time,divide(volchange, vol),title='Relative volume change',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_volumeChangeRelative.eps', color=True, solid=True)
        g._clear_queue()
        # Plotting the mouth aperture area
        g.ylabel('Area [mm2]')
        g.title('Mouth aperture area')
        g._add_to_queue([Gnuplot.Data(time,area,title='Area',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_area.eps', color=True, solid=True)
        g._clear_queue()
        # Plotting the estimated space-averaged flow speeds
        g.ylabel('Speed [mm/s]')
        g.set_range(option='yrange',value=(-1000, 1200))
        g.title('Spatially averaged intake speed')
        g._add_to_queue([Gnuplot.Data(time,speed,title='Speed',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_speed.eps' , color=True, solid=True)
        g._clear_queue()
        g.ylabel('Acceleration [mm/s2]')
        g.set_range(option='yrange',value=(min(accel[:len(accel)/4]), max(accel[:len(accel)/4])))
        g.title('Spatially averaged aperture acceleration')
        g._add_to_queue([Gnuplot.Data(time,accel,title='Acceleration',with_='lp 2 6')])
        g.refresh()
        g.hardcopy(filename=resultdir+name+'_acceleration.eps' , color=True, solid=True)
        g._clear_queue()

    if cutting:
        volPartChange = (volPart-append(volPart[0], volPart[0:-1]))/d
        speedPart = divide(volPartChange,areaPart)
        accelPart = (speedPart-append(speedPart[0], speedPart[0:-1]))/d
        rdict['Partial Volume'] = volPart
        rdict['Partial Area'] = areaPart
        rdict['Partial speed'] = speedPart
        rdict['Partial acceleration'] = accelPart

    writecsv(exportcsv, rdict)               # Export the results to a csv file!
    message("***\nOutput written to %s\n***" % exportcsv)

    # Creating the animation
    if anim:
        message('Executing animating command.\nThis can take a while!')
        try:
            system('convert -delay 10 -colors 256 -resize 800x800 %s*.png %s.gif' % (export, export))
        except:
            message('Image conversion failed.\nMaybe you don\'t have ImageMagick correctly installed.')
        system('rm %s*.png' % export)
    message('Done')
    return

# Definitions required by the model ____________________________

def cutModel(self, cutX=0.):
    """Cut the model at a longitudinal distance of cut percentage."""
    b = self.bbox()
    S = TriSurface(self.cutWithPlane([cutX, 0., 0.], [-1., 0., 0.],'-'))
    filling = S.fillBorder(method='border')[0]
    S = (S + filling).fixNormals()
    area = filling.area()
    return S, area

def fittingPlane(self):
    """Find a plane that minimizes the orthogonal distances with the points of self."""
    p = average(self, axis=0)            # The average of the coordinates is a point of the best fitting plane
    a = self-p
    b = a.transpose()
    c = dot(b, a)
    values, eigen = numpy.linalg.eig(c)  # This gives the eigenvalues and the eigenvectors, but in columns, not rows!
    n = eigen.transpose()[argsort(values)[0]]            # The appropriate eigenvector is the one that corresponds to the smallest eigenvalue.
    return p, n

def subdivide(P, n):
    """Use the BezierSpline method to find intermediate points of the points P."""
    bez = BezierSpline(P)
    new = []
    for i in range(len(P[0])-1):
        for j in range(0, n, 1):
            gape.append(bez.pointsAt(i+float(j)/n))
    new.append(bez.pointsAt(i+1))
    return asarray(new).reshape(-1, 3)

def writecsv(fn, d):
    """Write the data to a csv file."""
    fil = file(fn,'w')
    line = ''
    for i in d.keys():
        line = line + '\"' + i + '\"' + ';'
    fil.write(line+'\n')
    val = d.values()
    rows = len(val[0])
    for i in range(rows):
        line = ''
        for col in val:
            line = line + str(col[i]) + ';'
        fil.write(line+'\n')
    fil.close()
    return


###Menu Definitions###_______________________________________________________________________________________________

def suction():
    """Main definition that allows the creation of the model based on 9 reference point coordinates in a .csv file."""
    clear()
    global fn
    currentDir = os.getcwd()                            # This is the work directory
    fn = currentDir + '/input/examplePoints.csv'        # File containg the coordinates of the reference points
    scale=0.0609                                        # The scaling that should be applied to the coordinates (the resulting units should be millimeters)

    # Show the menu
    res = askItems(
        caption='Suction model',
        items=[
            T('Input parameters',[
                I('fn',fn,buttons=[('Select File',selectFile)],text='Coordinates'),     # Select the file with the coordinates
                I('name','Example',text='Project name'),                                # Give a name to the model
                I('scale',scale,text='Pixel scale'),                                    # The pixel scale denotes the size of a single pixel (1 pixel = 'Pixel scale' mm)
                I('bas',True,text='Draw basepoints'),                                   # Draw the basepoints
                I('ref',True,text='Draw reference points'),                             # Draw the reference points
                I('mod',False,text='Draw model points'),                                # Draw all the points of the model
                I('ax',True,text='Draw axes'),                                          # Show the XYZ axes
            ])
        ])
    if not res:
        return
    globals().update(res)
    name, scale, bas, ref, mod, ax = res['name'], res['scale'], res['bas'], res['ref'], res['mod'], res['ax']
    try:
        fil = file(fn,'r')
    except:
        warning('This file does not exist.')
        return

    le = len(fil.readlines())
    if not le == 10:
        warning('Wrong number of lines in the csv file (must be 9)')
        return

    fil.seek(0)

    # Read the coordinates
    points = ndarray([0,0]).astype(float)
    for i in range(le):
        points = append(points,fromfile(fil,dtype=float,count=3,sep=';'))
    if not len(points)==30:
        warning('Wrong data in csv file')
        return
    if ax:
        showaxes()
    global basepoints
    points = scale*points.reshape(-1,3)
    #print(points)
    pp = asarray([points[0], points[1], points[6], points[2], points[7]])
    p,  n = fittingPlane(pp)        # Get the plane that best fits these 5 points

    points = Coords(points).trl(-p)
    ey = [0., 1., 0.]  # Try to rotate the normal vector to the Y-axis
    ex = [1., 0., 0.]
    rotationangle,  rotationvector = rotateVectorOn(n, ey)
    points = points.rotate(rotationangle, axis=rotationvector)
    v1 = average([points[0], points[6]], axis=0) - average([points[1], points[7]], axis=0)
    v1[1] = 0.
    rotationangle,  rotationvector = rotateVectorOn(v1, ex)
    points = points.rotate(rotationangle, axis=rotationvector)
    referencepoints = points.copy()
    # Project the 5 planar points onto the XZ plane
    points[0, 1], points[1, 1], points[2, 1], points[6, 1], points[7, 1] = 0., 0., 0., 0., 0.
    # Project the central points to the YZ plane
    points[2, 2], points[8, 2] = 0., 0.
    referencepoints = referencepoints.trl(-points[2])
    points = points.trl(-points[2])

    if ref:
        draw(referencepoints,color=blue,marksize=6)
        drawNumbers(referencepoints,color=blue, offset=1, trl=[0.3, 0., 0.])
    P1 = average([points[0], abs(points[6])], axis=0)
    P2 = average([points[1], abs(points[7])], axis=0)
    P3, P4, P5, P6, P7, P8, P9 = points[2], points[3], points[4], points[5], points[8], points[2], points[9]
    P = Coords([P1,P2,P3,P4,P5,P6,P7,P8,P9])
    if bas:
        draw(P,color=black,marksize=6)
        drawNumbers(P,color=black, offset=1, trl=[0.3, 0., 0.])
    basepoints = P
    message('Basepoints are set')
    print(basepoints)
    model,P,area = fill(P)
    surf = TriSurface(model)
    vol = surf.volume()
    draw(surf)
    if mod:
        draw(P,color=green,marksize=6)
        drawNumbers(P,color=green)
    txt = 'The volume of the model is '+str(vol)+' mm'+chr(179)
    message(txt)
    drawText(txt,10,10,font='arial',size=12,color=blue)
    txt2 = 'The area of the mouth aperture is '+str(area)+' mm'+chr(178)
    message(txt2)
    drawText(txt2,10,30,font='arial',size=12,color=blue)
    export({name:surf})
    surface_menu.selection.set(name)


### Rotation definitions_______________________________________________________________________________________________________

def rotate():
    """Rotate parts of the model around a certain axis"""
    global basepoints
    if len(basepoints)==0:
        warning('You must first create a model!')
        return
    res = askItems([
        I('rot1',0.0,text='Hyoid rotation'),
        I('rot2',0.0,text='Lower jaw rotation'),
        I('rot3',0.0,text='Gill cover rotation'),
        I('rot4',0.0,text='Cheek plate rotation')
        ])
    if not res:
        return
    globals().update(res)
    if rot1 == 0.0 and rot2 == 0.0 and rot3 == 0.0 and rot4 == 0.0:
        warning('Define at least one angle!')
        return
    clear()
    drawNumbers(basepoints.copy())
    draw(basepoints)
    if rot1 != 0.0:
        basepoints = rotatehyoid(basepoints,rot1)
        txt='hyoid'
    if rot2 != 0.0:
        basepoints = rotatejaw(basepoints,rot2)
        txt='lower jaw'
    if rot3 != 0.0:
        basepoints = rotategill(basepoints,rot3)
        txt='gill cover'
    if rot4 != 0.0:
        basepoints = rotatecheek(basepoints,rot4)
        txt='cheek plate'
    model,P,area = fill(basepoints)
    surf = TriSurface(model)
    vol = surf.volume()
    draw(surf)
    drawNumbers(basepoints,color=[0.2,0.6,0.2])
    draw(basepoints,color=[0.2,0.6,0.2])
    message('The volume of the new model is '+str(vol)+' mm'+chr(179))
    message('The new area of the mouth aperture is '+str(area)+' mm'+chr(178))
    export({'After '+txt+' rotation':surf})
    surface_menu.selection.set('After '+txt+' rotation')

def rotatehyoid(points,angle):
    """Rotate the hyoid around an axis parallel to the Z-axis."""
    P = points.copy()
    P[6] = P[6].rotate(axis=2, angle=angle, around=P[4])
    return P

def rotatejaw(points,angle):
    """Rotate the lower jaw around an axis parallel to the Z-axis"""
    P = points.copy()
    P[7] = P[7].rotate(axis=2, angle=angle, around=P[3])
    P[8] = P[8].rotate(axis=2, angle=angle, around=P[3])
    return P

def rotategill(points,angle):
    """Rotate the gill cover around the axis created by the two points in common with the cheek plate"""
    P = points.copy()
    P[5] = P[5].rotate(axis=(P[4]-P[0])/distance(P[4],P[0]), angle=angle, around=P[0])
    return P

def rotatecheek(points,angle):
    """Rotate the cheek plate around the axis created by the two points in common with the skull roof"""
    P = points.copy()
    ax = (P[1]-P[0])/distance(P[1],P[0])
    P[3] = P[3].rotate(axis=ax, angle=angle, around=P[0])
    P[4] = P[4].rotate(axis=ax, angle=angle, around=P[0])
    P[5] = P[5].rotate(axis=ax, angle=angle, around=P[0])
    P[8] = P[8].rotate(axis=ax, angle=angle, around=P[0])
    return P

def rotateall(points,angles):
    """Rotation around jaw, hyoid, cheek and gill at the same time"""
    if not len(angles)==4:
        warning('Wrong number of angles')
        return
    P = rotategill(rotatecheek(rotatehyoid(rotatejaw(points,angles[0]),angles[1]),angles[2]),angles[3])
    return P

def rotateinterval():
    """Calculates and plots the volume of the model in function of a chosen variable angle"""
    global basepoints
    if len(basepoints)==0:
        warning('You must first create a model!')
        return
    res = askItems([
        I('name','plot',text='Model name'),
        I('par',choices=['Hyoid','Lowerjaw','Gills','Cheeks'],text='Parameter'),
        I('mi',0.,text='Minimum'),
        I('ma',20.,text='Maximum'),
        I('ste',2.,text='Step'),
        I('drawing',True,text='Draw models'),
        I('gape',True,text='Show  gape distance'),
        ])
    if not res:
        return
    globals().update(res)
    angles = arange(mi,ma+1,ste)
    if drawing:
        clear()
        wireframe()
    volumes = ndarray([0,0]).astype(float)
    areas = ndarray([0,0]).astype(float)
    if gape:
        gap = ndarray([0,0]).astype(float)
    for i in angles:
        if par == 'Hyoid':
            P = rotatehyoid(basepoints,i)
        if par == 'Lowerjaw':
            P = rotatejaw(basepoints,i)
        if par == 'Gills':
            P = rotategill(basepoints,i)
        if par == 'Cheeks':
            P = rotatecheek(basepoints,i)
        model,Pnew,area = fill(P)
        surf = TriSurface(model)
        volumes = append(volumes,surf.volume())
        areas = append(areas,area)
        if gape:
            gap = append(gap,distance(P[2],P[7]))
        if drawing:
            draw(surf)
    plot2d(volumes,par,angles)
    message('The volumes of the intermediate models are:\n'+str(volumes))
    if gape:
        message('The gape distances are:\n'+str(gap))
        plot2dGape(gap,par,angles)
        exportPlot(volumes,areas,gap,par,angles,name=name)
    else:
        exportPlot(volumes,areas,par1=par,angles1=angles,name=name)

def rotatetwo():
    """Calculates the volume of the model in function of two variable angles"""
    if len(basepoints)==0:
        warning('You must first create a model!')
        return
    res = askItems([
        I('name','plot',text='Model name'),
        I('par1','Hyoid',choices=['Hyoid','Lowerjaw','Gills','Cheeks'],text='Parameter 1'),
        I('mi1',0.,text='Minimum 1'),
        I('ma1',20.,text='Maximum 1'),
        I('st1',5.,text='Step 1'),
        I('par2','Lowerjaw',choices=['Hyoid','Lowerjaw','Gills','Cheeks'],text='Parameter 2'),
        I('mi2',0.,text='Minimum 2'),
        I('ma2',20.,text='Maximum 2'),
        I('st2',5.,text='Step 2'),
        I('dr',True,text='Draw in 3D'),
        I('gape',True,text='show gape distance'),
        ])
    if not res:
        return
    globals().update(res)
    angles1 = arange(mi1,ma1+1,st1)
    angles2 = arange(mi2,ma2+1,st2)
    if gape:
        gap = ndarray([0,0]).astype(float)
    num = len(angles1)
    tot = num*len(angles2)
    if (tot>100):
        ask = ask('Calculating this much combinations ('+str(tot)+') can require a lot of time.\n Are you sure that you want to continu?')
        if not ask:
            return
    if par1 == par2:
        warning('The two parameters can not be the same ('+par1+')')
        return
    volumes = ndarray([0,0]).astype(float)
    areas = ndarray([0,0]).astype(float)
    for i in angles1:
        for j in angles2:
            if par1 == 'Hyoid':
                P = rotatehyoid(basepoints,i)
            if par1 == 'Lowerjaw':
                P = rotatejaw(basepoints,i)
            if par1 == 'Gills':
                P = rotategill(basepoints,i)
            if par1 == 'Cheeks':
                P = rotatecheek(basepoints,i)
            if par2 == 'Hyoid':
                P = rotatehyoid(P,j)
            if par2 == 'Lowerjaw':
                P = rotatejaw(P,j)
            if par2 == 'Gills':
                P = rotategill(P,j)
            if par2 == 'Cheeks':
                P = rotatecheek(P,j)
            if gape:
                gap = append(gap,distance(P[2],P[7]))
            model,Pnew,area = fill(P)
            surf = TriSurface(model)
            volumes = append(volumes,surf.volume())
            areas = append(areas,area)
    volumes = volumes.reshape(-1,len(angles2))
    #Plot the data
    if gape:
        gap = gap.reshape(-1,len(angles2))
        message('The gape distances are:\n'+str(gap))
        plot2dGape(gap,par1=par1,angles1=angles1,par2=par2,angles2=angles2)
    if dr:
        plot3d(volumes,par1,angles1,par2,angles2)
    else:
        plot2d(volumes,par2,angles2,par1,angles1)
    print(volumes)
    if gape:
        exportPlot(volumes,areas,gap,par1,angles1,par2,angles2,name=name)
    else:
        exportPlot(volumes,areas,par1=par1,angles1=angles1,par2=par2,angles2=angles2,name=name)

def rotatethree():
    """Calculates the volume of the model in function of three variable angles"""
    if len(basepoints)==0:
        warning('You must first create a model!')
        return
    ask = askItems([
        I('name','plot3d',text='Model name'),
        I('Parameter 1',None,choices=['Hyoid','Lowerjaw','Gills','Cheeks']),
        I('Minimum 1',0.),
        I('Maximum 1',90.),
        I('Step 1',30.),
        I('Parameter 2','Lowerjaw',choices=['Hyoid','Lowerjaw','Gills','Cheeks']),
        I('Minimum 2',0.),
        I('Maximum 2',90.),
        I('Step 2',30.),
        I('Parameter 3','Cheeks',choices=['Hyoid','Lowerjaw','Gills','Cheeks']),
        I('Minimum 3',-10.),
        I('Maximum 3',10.),
        I('Step 3',10.)
        ])
    if not ask:
        return
    par1 = ask['Parameter 1']
    angles1 = arange(ask['Minimum 1'],ask['Maximum 1']+1,ask['Step 1'])
    par2 = ask['Parameter 2']
    angles2 = arange(ask['Minimum 2'],ask['Maximum 2']+1,ask['Step 2'])
    par3 = ask['Parameter 3']
    angles3 = arange(ask['Minimum 3'],ask['Maximum 3']+1,ask['Step 3'])
    num = len(angles3)
    tot = num*len(angles2)*len(angles1)
    name = ask['name']
    if (tot>200):
        ask = ack('Calculating this much combinations ('+str(tot)+') can require a lot of time.\n Are you sure that you want to continu?')
        if not ask:
            return
    if par1 == par2 or par2 == par3 or par1 == par3:
        warning('You should choose three different parameters')
        return
    volumes = ndarray([0,0]).astype(float)
    areas = ndarray([0,0]).astype(float)
    for k in angles3:
        for i in angles1:
            for j in angles2:
                if par1 == 'Hyoid':
                    P = rotatehyoid(basepoints,i)
                if par1 == 'Lowerjaw':
                    P = rotatejaw(basepoints,i)
                if par1 == 'Gills':
                    P = rotategill(basepoints,i)
                if par1 == 'Cheeks':
                    P = rotatecheek(basepoints,i)
                if par2 == 'Hyoid':
                    P = rotatehyoid(P,j)
                if par2 == 'Lowerjaw':
                    P = rotatejaw(P,j)
                if par2 == 'Gills':
                    P = rotategill(P,j)
                if par2 == 'Cheeks':
                    P = rotatecheek(P,j)
                if par3 == 'Hyoid':
                    P = rotatehyoid(P,k)
                if par3 == 'Lowerjaw':
                    P = rotatejaw(P,k)
                if par3 == 'Gills':
                    P = rotategill(P,k)
                if par3 == 'Cheeks':
                    P = rotatecheek(P,k)
                model,Pnew,area = fill(P)
                surf = TriSurface(model)
                volumes = append(volumes,surf.volume())
                areas = append(areas,area)
    volumes = volumes.reshape(-1,len(angles1),len(angles2))
    #Plotting the data
    plot3d(volumes,par1,angles1,par2,angles2,par3,angles3,name)
    print(volumes)
    exportPlot(volumes,areas,par1,angles1,par2,angles2,par3,angles3,name)

###_______________________________________________________________________________________________________

def flowspeed():
    """Calculate the flow speed through the mout of the fish (steady flow approximation)"""
    if len(basepoints)==0:
        warning('You must first create a model!')
        return
    # Reading the gape curve
    message('Select the .csv file with the gape points')
    types = ['Point files (*.csv)', 'All Files (*)']
    fn = askFilename(pf.cfg['workdir'],types,exist=True)
    if not fn:
        return
    d = 0.0005
    points = selectequalpoints(subdivide(expand(readfile(fn))),D=d)
    points[:,1] = lowpass(points[:,1],mu1=0,n=6)
    time = points[:,0]
    gape = points[:,1]
    #End of reading
    model0,Pnew0,area0 = fill(basepoints)
    gapeangle = array([angleByCoord(basepoints[2],[basepoints[3,0],0,basepoints[3,2]],basepoints[2]-i)*180./pi for i in gape])
    angle = 45./max(gapeangle)*gapeangle
    angles = zeros([len(angle),4])
    cor = angle[0]
    angles[:,0]=angle
    angles[:,1][50:]=(angle[:-50]-cor)/3
    angles[:,2][75:]=(angle[:-75]-cor)/4
    angles[:,3][100:]=(angle[:-100]-cor)/3
    #print(angles[70:80])
    tmp = [fill(rotateall(basepoints,i)) for i in angles]
    #model,Pnew,area = tmp[:,0],tmp[:,1],tmp[:,2]
    volumes = array([TriSurface(tmp[i][0]).volume() for i in range(len(angles))])
    areas = array([tmp[i][2]-area0 for i in range(len(angles))])
    #print(volumes[:10],areas[:10])
    volumechange = lowpass((volumes-append(volumes[0],volumes[0:-1]))/d,lambda1=0.5,mu1=-0.55,n=6)
    speed = divide(volumechange,areas)
    #g=Gnuplot.Gnuplot(persist=1)
    #g.plotcmd = 'plot'
    #g._clear_queue()
    #g.xlabel('Time [s]')
    #g.ylabel('Fluid speed [mm/s]')
    #g.title('Speed at the mouth aperture of the fish')
    #g._add_to_queue([Gnuplot.Data(time,speed,title='Speed',with_='lp 2 6')])
    #g._add_to_queue([Gnuplot.Data(time,volumechange/max(volumechange)*max(speed),title='Volumes',with_='lp 7 0')])
    #g.refresh()


### Other definitions _______________________________________________________________________________________________________

def drawmodel():
    """Draw the selected models"""
    F = surface_menu.selection.check()
    if not F:
        return
    layout(nvps=1)
    clear()
    selection.draw()
    view('top')

def rename():
    """Rename the selected model"""
    F = surface_menu.selection.check(single=True)
    if not F:
        return
    ask = askItems([('New name of the model','New model')])
    if not ask:
        return
    name = ask['New name of the model']
    export({name:F})
    surface_menu.selection.set(name)

def writemodel():
    """Write the model to a new .stl file, future loading might cause a renumbering of the the points"""
    F= surface_menu.selection.check(single=True)
    if not F:
        return
    types = ['Surface Files (*.stl)', 'All Files (*)']
    fn = askFilename(pf.cfg['workdir'],types,exist=False)
    if not fn:
        return
    G = F.select(where(F.areaNormals()[0]>0)[0]) # This is needed to remove triangles with area=0, which would cause an error when trying to load the stl, or convert it to gts.
    G.write(fn)

def writereferencepoints():
    """Write a .csv file with reference points that will generate the current basepoints upon execution. As the csv currently has to contain integers, there will be an approximation error with this method!!!"""
    if shape(basepoints)!=(9,3):
        warning('No basepoints found')
        return
    types = ['Reference point files (*.csv)', 'All Files (*)']
    fn = askFilename(pf.cfg['workdir'],types,exist=False)
    ask = askItems([('Pixel size',0.0609)])
    if not ask:
        return
    sc = 1./ask['Pixel size']
    if not fn:
        return
    referencepoints = ndarray([0,0]).astype(int)
    referencepoints = append(referencepoints,[basepoints[0][0]*sc,-basepoints[0][1]*sc,basepoints[0][2]*sc])
    referencepoints = append(referencepoints,[basepoints[1][0]*sc,-basepoints[1][1]*sc,basepoints[1][2]*sc])
    referencepoints = append(referencepoints,basepoints[2]*sc)
    referencepoints = append(referencepoints,[basepoints[3][0]*sc,-basepoints[3][1]*sc,basepoints[3][2]*sc])
    referencepoints = append(referencepoints,[basepoints[4][0]*sc,-basepoints[4][1]*sc,basepoints[4][2]*sc])
    referencepoints = append(referencepoints,[basepoints[5][0]*sc,-basepoints[5][1]*sc,basepoints[5][2]*sc])
    referencepoints = append(referencepoints,basepoints[0]*sc)
    referencepoints = append(referencepoints,basepoints[1]*sc)
    referencepoints = append(referencepoints,basepoints[6]*sc)
    referencepoints = append(referencepoints,basepoints[8]*sc)
    referencepoints = referencepoints.reshape(-1,3)
    message('Reference point coordinates:')
    for i in referencepoints:
        message('%s;%s;%s\n' % (int(i[0]),int(i[1]),int(i[2])))
    fil = file(fn,'w')
    for i in referencepoints:
        fil.write('%s;%s;%s\n' % (int(i[0]),int(i[1]),int(i[2])))
    fil.close()
    warning('Reference point file written')

###____________________________________________________________________________________________________________________________________

def func(x, a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10):
    """Return a ploynomial result."""
    return a0+a1*x+a2*x**2+a3*x**3+a4*x**4+a5*x**5+a6*x**6+a7*x**7+a8*x**8+a9*x**9+a10*x**10

def degree10(x, p):
    """Return the polynomial with factors p"""
    [a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10] = p
    tmp = a0+a1*x+a2*x**2+a3*x**3+a4*x**4+a5*x**5+a6*x**6+a7*x**7+a8*x**8+a9*x**9+a10*x**10
    return tmp

def deriv1degree10(x,p):
    """Return the first derivative of the polynomial with factors p"""
    return degree10(x,[1.*p[1],2.*p[2],3.*p[3],4.*p[4],5.*p[5],6.*p[6],7.*p[7],8.*p[8],9.*p[9],10.*p[10],0.])

def calculatevolume():
    """Calculate the volume of the selected model"""
    F = surface_menu.selection.check(single=True)
    if not F:
        return
    clear()
    vol = F.volume()
    draw(F)
    drawText('The total volume equals %s mm%s' %(vol,chr(179)),10,20,color=blue)
    message('The total volume equals %s mm%s' %(vol,chr(179)))

def openarea():
    """Calculates the area of the mouth section."""
    F = surface_menu.selection.check(single=True)
    if not F:
        return
    G = F.select(where(F.prop==8)[0])
    print(where(F.prop==8)[0])
    txt = 'The area of the mouth aperture is %s mm%s' % (G.area(),chr(178))
    message(txt)
    drawText(txt,10,30,font='arial',size=12,color=blue)
    export({'Mouth section':G})

def gapeDist():
    """Calculates the mouth aperture of the current model"""
    try:
        b = basepoints
    except:
        message('Set the basepoints first')
        return
    d = distance(b[7],b[2])
    draw(Coords([b[7],b[2]]),color=green,marksize=6)
    zoomAll()
    txt = 'The gape distance of the mouth aperture is %s mm' % (d)
    message(txt)
    drawText(txt,10,30,font='arial',size=12,color=blue)

def setbasepoints():
    """Manually change the coordinates of the basepoints. If no basepoints are present, they can be manually created here."""
    global basepoints
    temp = basepoints.copy()
    if len(basepoints)==0:
        basepoints = zeros([8,3])
    ask = askItems([('Model name','Manual basepoints'),('P0',[basepoints[0,0],basepoints[0,1],basepoints[0,2]]),('P1',[basepoints[1,0],basepoints[1,1],basepoints[1,2]]),('P2',[basepoints[2,0],basepoints[2,1],basepoints[2,2]]),('P3',[basepoints[3,0],basepoints[3,1],basepoints[3,2]]),('P4',[basepoints[4,0],basepoints[4,1],basepoints[4,2]]),('P5',[basepoints[5,0],basepoints[5,1],basepoints[5,2]]),('P9',[basepoints[6,0],basepoints[6,1],basepoints[6,2]]),('P10',[basepoints[7,0],basepoints[7,1],basepoints[7,2]]),('P11',[basepoints[8,0],basepoints[8,1],basepoints[8,2]])])
    if not ask:
        return
    name = ask['Model name']
    basepoints = Coords([ask['P0'],ask['P1'],ask['P2'],ask['P3'],ask['P4'],ask['P5'],ask['P9'],ask['P10'],ask['P11']])
    print(basepoints)
    if not checkbasepoints():
        basepoints = temp
        return
    model,P,area = fill(basepoints)
    surf = TriSurface(model)
    vol = surf.volume()
    draw(surf)
    message('The volume of the model is '+str(vol)+' mm'+chr(179))
    export({name:surf})
    surface_menu.selection.set(name)

def extractbasepoints():
    """Set the basepoints based on the currently selected model"""
    F = surface_menu.selection.check(single=True)
    if not F:
        return
    global basepoints
    cor = F.coords
    new = Coords([cor[5],cor[51],cor[36],cor[10],cor[8],cor[2],cor[57],cor[36]])
    basepoints = new
    clear()
    draw(F)
    showbasepoints()
    message('Basepoints set according to the currently selected model')

### Some more functionalities that were added to the menu ________________________________________________________________

def showbasepoints():
    """Draws the basepoints that are set, as well as their respective numbers"""
    if len(basepoints)==0:
        warning('No basepoints set')
        return
    draw(basepoints,color=red,marksize=8)
    drawNumbers(basepoints,color=red)
    message('The basepoint coordinates are: \n %s' %basepoints)

def showcsvpoints():
    """Draw the reference points from the csv file"""
    ask = askItems([('Pixel scale',0.0609)])
    if not ask:
        return
    scale = ask['Pixel scale']
    message('Select the .csv file with the coordinates')
    types = ['Point files (*.csv)', 'All Files (*)']
    fn = askFilename(pf.cfg['workdir'],types,exist=True)
    if not fn:
        return
    fil = file(fn,'r')
    le = len(fil.readlines())
    if not le == 10:
        warning('Wrong number of lines in the csv file (must be 9)')
        return
    fil.seek(0)
    points = ndarray([0,0]).astype(int)
    for i in range(le):
        points = append(points,fromfile(fil,dtype=int,count=3,sep=';'))
    if not len(points)==30:
        warning('Wrong data in csv file')
        return
    points = Coords(scale*points.reshape(-1,3))
    draw(points,color=blue,marksize=4)
    drawNumbers(points,color=blue)

def showsize():
    """Print the lengths of the bounding box edges. This is thus a measure for the overall size of the respective model"""
    n=0
    drawmodel()
    for f in selection.names:
        F = named(f)
        box = F.bbox()
        x = abs(box[0,0]-box[1,0])
        y = abs(box[0,1]-box[1,1])
        z = abs(box[0,2]-box[1,2])
        drawText("%s has dimensions %s, %s, %s" % (f,x,y,z),10,10+n,color=blue)
        n += 20

def showbbox():
    """Draw the bounding box of the model"""
    for f in selection.names:
        F = named(f)
        bb = F.bbox()
        x1,y1,z1 = bb[0,0],bb[0,1],bb[0,2]
        x2,y2,z2 = bb[1,0],bb[1,1],bb[1,2]
        P1 = [x1,y1,z1]
        P2 = [x2,y1,z1]
        P3 = [x2,y2,z1]
        P4 = [x1,y2,z1]
        P5 = [x1,y1,z2]
        P6 = [x2,y1,z2]
        P7 = [x2,y2,z2]
        P8 = [x1,y2,z2]
        box = Formex([[P1,P2],[P2,P3],[P3,P4],[P4,P1],[P5,P6],[P6,P7],[P7,P8],[P8,P5],[P1,P5],[P2,P6],[P3,P7],[P4,P8]])
        draw(box)
        export({'Bounding box':box})

def showaxes():
    """Draw the main axis of the model, with X being red, Y being green and Z being blue"""
    a = 40
    Axes =  Formex([[[0,0,0],[a,0,0]],[[0,0,0],[0,a/2,0]],[[0,0,0],[0,0,a/2]]])
    draw(Axes,linewidth=2.0,color=[[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]],bbox=None,view='__last__')
    zoomAll()
    export({'Axes':Axes})

def showcoords():
    """Show the coordinates of a picked mesh point"""
    F= surface_menu.selection.check(single=True)
    if not F:
        return
    drawmodel()
    renderMode('wireframe')
    p = pick('point',filtr='single')[0]
    P = F.coords[p][0]
    drawText("The coordinates of the selected point (%s) are [%s, %s, %s]" %(p[0],P[0],P[1],P[2]),10,10,color=blue)
    message(P)

def showdistance():
    """Give the distance between two selected points"""
    F= surface_menu.selection.check(single=True)
    if not F:
        return
    drawmodel()
    renderMode('wireframe')
    p1 = pick('point',filtr='single')[0]
    P1 = F.coords[p1][0]
    p2 = pick('point',filtr='single')[0]
    P2 = F.coords[p2][0]
    dist = sqrt((P1[0]-P2[0])**2+(P1[1]-P2[1])**2+(P1[2]-P2[2])**2)
    draw(Formex([[P1,P2]]),color=blue,linewidth=2.0)
    draw(Formex([P1,P2]),color=red)
    drawText("The distance between the two points equals %s mm" %dist,10,10,color=blue)
    message(dist)

def showangle():
    """Give the angle between three selected points"""
    F= surface_menu.selection.check(single=True)
    if not F:
        return
    drawmodel()
    renderMode('wireframe')
    p1 = pick('point',filtr='single')[0]
    P1 = F.coords[p1][0]
    p2 = pick('point',filtr='single')[0]
    P2 = F.coords[p2][0]
    p3 = pick('point',filtr='single')[0]
    P3 = F.coords[p3][0]
    draw(Formex([[P1,P2],[P2,P3]]),color=blue,linewidth=2.0)
    draw(Formex([P1,P2,P3]),color=red)
    angle = angleByCoord(P1,P2,P3)/pi*180
    drawText("The angle between the three points equals %s degrees" %angle,10,30,color=blue)
    message(angle)

def drawlines():
    """Draw lines in the model, eg the measured lines"""
    F= surface_menu.selection.check(single=True)
    if not F:
        return
    p1 = pick('point',filtr='single')[0]
    P1 = F.coords[p1][0]
    p2 = pick('point',filtr='single')[0]
    P2 = F.coords[p2][0]
    draw(Formex([[P1,P2]]),color=[0.4,0.8,0.4],linewidth=4.0)
    draw(Formex([P1,P2]),color=red)

###Other Definitions###_______________________________________________________________________________________________

def createQuad(P):
    """Create two triangles out of four points"""
    return Formex([[P[0],P[1],P[2]],[P[0],P[2],P[3]]])

def createTri(P):
    """Create one triangle out of three points"""
    return Formex([[P[0],P[1],P[2]]])

def vnorm(P):
    """Returns the vector norm of the point"""
    return sqrt(P[0]**2+P[1]**2+P[2]**2)

def distance(P1,P2):
    """Returns the distance between two points, based on their coordinates"""
    return sqrt((P2[0]-P1[0])**2+(P2[1]-P1[1])**2+(P2[2]-P1[2])**2)

def angleByLength(L1,L2,L3):
    """Returns the angle of a triangle based on the lengths of the sides. The second length is the one oposite of the angle!"""
    return arccos((L1**2+L3**2-L2**2)/(2*L1*L3))

def angleByCoord(P1,P2,P3):
    """Returns the angle of a triangle based on the coordinates of the points. The second point is the one where the angle is calculated!"""
    return angleByLength(distance(P1,P2),distance(P1,P3),distance(P2,P3))

def projectionOnPlane(point,planepoint1,planepoint2,planepoint3):  # NOT USED ANYMORE.... MAY BE DELETED LATER ON
    """Calculate the coordinates of the projected point onto a plane defined by three points"""
    vect1 = planepoint1-planepoint2
    vect2 = planepoint3-planepoint2
    N = cross(vect1,vect2)/vnorm(cross(vect1,vect2))
    dist = point.distanceFromPlane(planepoint2,N)
    return Coords(point-dist*N)

def plot2d(volumes,par2,angles2,par1=0,angles1=0,name='plot'):
    """Plot the volume and change in volume in 2D"""
    g=Gnuplot.Gnuplot(persist=1)
    g.plotcmd = 'plot'
    g._clear_queue()
    g.xlabel(par2+' angle ['+chr(176)+']')
    g.ylabel('Volume [mm'+chr(179)+']')
    if par1==0:
        g.title('Volume with variable '+par2+' angle')
        g._add_to_queue([Gnuplot.Data(angles2,volumes,title='Internal volume',with_='lp 3 3')])
    else:
        g.title('Volume with variable '+par1+' and '+par2+' angle')
        g._add_to_queue([Gnuplot.Data(angles2,volumes[i],title=str(par1)+' '+str(angles1[i])+chr(176),with_='linesp') for i in range(len(volumes))])
    g.refresh()
    g('set encoding iso_8859_1')
    g.hardcopy(name+'.ps', enhanced=1, color=1)

    h=Gnuplot.Gnuplot(persist=1)
    h.plotcmd = 'plot'
    h._clear_queue()
    h.xlabel(par2+' angle ['+chr(176)+']')
    h.ylabel('Volume change [mm'+chr(179)+'/'+chr(176)+']')
    st = angles2[1]-angles2[0]
    if par1==0:
        h.title('Volume change with variable '+par2+' angle')
        h._add_to_queue([Gnuplot.Data(angles2[0:-1],differential(volumes,st),title='Internal volume change',with_='lp 2 3')])
    else:
        h.title('Volume change with variable '+par1+' and '+par2+' angle')
        h._add_to_queue([Gnuplot.Data(angles2[0:-1]+0.5*st,differential(volumes[i],st),title=str(par1)+' '+str(angles1[i])+chr(176),with_='linesp') for i in range(len(volumes))])
    h.refresh()
    h('set encoding iso_8859_1')
    h.hardcopy(name+'2.ps', enhanced=1, color=1)

def plot2dGape(gap,par2,angles2,par1=0,angles1=0,name='plotGape'):
    """Plot the gape distance in 2D"""
    g=Gnuplot.Gnuplot(persist=1)
    g.plotcmd = 'plot'
    g._clear_queue()
    g.xlabel(par2+' angle ['+chr(176)+']')
    g.ylabel('Gape distance [mm]')
    if par1==0:
        g.title('Gape with variable '+par2+' angle')
        g._add_to_queue([Gnuplot.Data(angles2,gap,title='Internal volume',with_='lp 3 3')])
    else:
        g.title('Gape with variable '+par1+' and '+par2+' angle')
        g._add_to_queue([Gnuplot.Data(angles2,gap[i],title=str(par1)+' '+str(angles1[i])+chr(176),with_='linesp') for i in range(len(gap))])
    g.refresh()
    g('set encoding iso_8859_1')
    g.hardcopy(name+'.ps', enhanced=1, color=1)

def plot3d(volumes,par1,angles1,par2,angles2,par3=0,angles3=0,name='plot3d'):
    """Plot the volume and change in volume in 3D"""
    g=Gnuplot.Gnuplot(persist=1)
    g._clear_queue()
    g.xlabel(par1+' angle ['+chr(176)+']')
    g.ylabel(par2+' angle ['+chr(176)+']')
    g.zlabel('Volume [mm'+chr(179)+']')
    g.plotcmd = 'splot'
    if par3==0:
        g.title('Volume with variable %s and %s angle' %(par1,par2))
        g._add_to_queue([Gnuplot.GridData(volumes,angles1,angles2,binary=0,with_='linesp 2 3', inline=1,title='Internal volume')])
    else:
        g.title('Volume with variable %s, %s and %s angle' %(par1,par2,par3))
        g._add_to_queue([Gnuplot.GridData(volumes[i],angles1,angles2,binary=0,with_='linesp', inline=1,title=str(par3)+' angle '+str(angles3[i])+chr(176)) for i in range(len(volumes))])
    g.refresh()
    g('set encoding iso_8859_1')
    g.hardcopy(name+'.ps', enhanced=1, color=1)

    h=Gnuplot.Gnuplot(persist=1)
    h._clear_queue()
    h.xlabel(par1+' angle ['+chr(176)+']')
    h.ylabel(par2+' angle ['+chr(176)+']')
    h.zlabel('Volume change [mm'+chr(179)+'/'+chr(176)+']')
    h.plotcmd = 'splot'
    st1=angles1[1]-angles1[0]
    st2=angles2[1]-angles2[0]
    if par3==0:
        h.title('Volume change with variable %s and %s angle' %(par1,par2))
        h._add_to_queue([Gnuplot.GridData(differential3d(volumes,st1,st2),angles1[0:-1]+0.5*st1,angles2[0:-1]+0.5*st2,binary=0,with_='linesp 3 3', inline=1,title='Internal volume change')])
    else:
        h.title('Volume change with variable %s, %s and %s angle' %(par1,par2,par3))
        h._add_to_queue([Gnuplot.GridData(differential3d(volumes[i],st1,st2),angles1[0:-1]+0.5*st1,angles2[0:-1]+0.5*st2,binary=0,with_='linesp', inline=1,title=str(par3)+' angle '+str(angles3[i])+chr(176)) for i in range(len(volumes))])
    h.refresh()
    h('set encoding iso_8859_1')
    h.hardcopy(name+'.ps', enhanced=1, color=1)

def exportPlot(volumes,areas,gape=[0],par1=0,angles1=0,par2=[0],angles2=0,par3=[0],angles3=0,name='plot'):
    "Export the plot data to a file called name.csv"
    fn = os.getcwd()+'/'+name+'.csv'
    fil = file(fn,'w')
    vol = volumes.ravel()
    ar = areas
    if len(gape) < 2:
        gape = -ones([len(vol)])
    else:
        gape = gape.ravel()
    if len(par2) < 2:
        fil.write('%s;Volume;Area;Gape\n' % par1)
    elif len(par3) < 2:
        fil.write('%s;%s;Volume;Area;Gape\n' % (par1,par2))
    else:
        fil.write('%s;%s;%s;Volume;Area;Gape\n' % (par1,par2,par3))
    i=0
    for a1 in angles1:
        if len(par2)<2:
            fil.write('%s;%s;%s;%s\n' % (a1,vol[i],ar[i],gape[i]))
            i+=1
        else:
            for a2 in angles2:
                if len(par3)<2:
                    fil.write('%s;%s;%s;%s;%s\n' % (a1,a2,vol[i],ar[i],gape[i]))
                    i+=1
                else:
                    for a3 in angles3:
                        fil.write('%s;%s;%s;%s;%s;%s\n' % (a1,a2,a3,vol[i],ar[i],gape[i]))
                        i+=1
    fil.write('\n')
    global basepoints
    points = [[basepoints[0][0],-basepoints[0][1],basepoints[0][2]],[basepoints[1][0],-basepoints[1][1],basepoints[1][2]],
        basepoints[2],[basepoints[3][0],-basepoints[3][1],basepoints[3][2]],
        [basepoints[4][0],-basepoints[4][1],basepoints[4][2]],[basepoints[5][0],-basepoints[5][1],basepoints[5][2]],
        basepoints[0],basepoints[1],basepoints[6],basepoints[8]]
    names = ['Hyomandibula caudal articulation (left)',
        'Palatine rostral tip (left)',
        'Premaxillary rostral tip',
        'Mandibular articulation (left)',
        'Preopercle lower tip (left)',
        'Opercle caudodorsal tip (left)',
        'Hyomandibula caudal articulation (right)',
        'Palatine rostral tip (right)',
        'Hyoid symphysis',
        'Maxillary-Dentary joint (left)']
    for i,p in enumerate(points):
        fil.write('%s,%s;%s;%s\n' % (names[i],p[0],p[1],p[2]))
        print(names[i],p[0],p[1],p[2])
    fil.close()
    message('File %s written' %fn)

def differential(volumes,step=1):
    """Returns the differential of the volume curve in 2D"""
    diff=[(volumes[i+1]-volumes[i])/step for i in range(len(volumes)-1)]
    return diff

def differential3d(volumes,step1=1,step2=1):
    """Returns the differential of the volume curve in 3D"""
    (x,y) = shape(volumes)
    diff =[[0.25*((volumes[i+1,j]-volumes[i,j])/step1+(volumes[i,j+1]-volumes[i,j])/step2+(volumes[i+1,j+1]-volumes[i,j+1])/step1+(volumes[i+1,j+1]-volumes[i+1,j])/step2) for j in range(y-1)] for i in range(x-1)]
    return diff

def checkbasepoints():
    """Checks whether the values of the basepoints are realistic"""
    b = basepoints
    if len(b)==0:
        warning('No basepoints set')
        return False
    message('%s basepoints with each %s coordinates' % shape(b))
    if shape(b)!=(10,3):
        warning('Inappropriate shape of the basepoints')
        return False
    check = b[0,0]==0 and b[0,1]>0 and b[0,2]==0 and b[1,0]>0 and b[1,1]>0 and b[1,2]==0 and b[2,0]>0 and b[2,1]==0 and b[2,2]==0 and b[3,0]>b[4,0] and b[3,1]>0 and b[3,2]>0 and b[4,0]>b[5,0] and b[4,1]>0 and b[4,2]>0 and b[5,1]>0 and b[5,2]>0 and b[6,0]>0 and b[6,1]==0 and b[6,2]>0 and b[7,0]>0 and b[7,1]==0 and b[7,2]>=0 and b[8,0]>b[3,0] and b[8,1]>0
    if check:
        message('Basepoints are valid')
        warning('Basepoints checked')
        return True
    else:
        warning('Basepoints have invalid values!')
        return False

def selectequalpoints(P,D=0.1):
    """Select a subarray of P with points at distance P"""
    temp = [0,P[0,1],0]
    a=1
    for i in range(len(P)-1):
        if P[i,0] > a*D:
            temp = append(temp,[a*D,P[i+1,1],0])
            a += 1
    temp = append(temp,[max(P[:,0]),P[-1,1],0])
    return temp.reshape(-1,3)

def readfile(f,count=2):
    fil = file(f,'r')
    le = len(fil.readlines())-1
    fil.seek(0)
    header = fil.readline()
    points = ndarray([0,0])
    for i in range(le):
        points = append(points,fromfile(fil,dtype=float,count=count,sep=','))
    points = points.reshape(-1,2)
    return points.reshape(-1,2)

def expand(angles):
    return asarray([[i[0],i[1],0] for i in angles])

def subdivide(points,sp=10, smooth=2):
    """Subdivide the given points with sp additional points"""
    N = NaturalSpline(points,closed=False)
    p = N.subPoints(sp,[0.0,0.0])
    for i in range(smooth):
        q = p.copy()
        p[1:-1] = (q[:-2]+q[1:-1]+q[2:])/3.
    return p

def subdivideAndSmooth(p, points=100, smooth=10, sp=5):
    """Subdivide the given points with sp additional points and smoothen them"""
    for i in range(smooth):
        p = movingAver(p)
    N = NaturalSpline(p,closed=False)
    p = N.subPoints(sp,[0.0,0.0])
    begin, end = p[0, 0], p[-1, 0]
    step = (end - begin) / float(points)
    t, v = p[:, 0], p[:, 1]
    q = empty([points+1, 2])
    for i in range(points):
        q[i, 0] = begin + i*step
        tp, j = begin-1., 0
        while tp < q[i, 0]:
            qq = v[j]
            tp = t[j]
            j += 1
        q[i, 1] = qq
    q[-1] = [end, p[-1, 1]]
    for i in range(smooth/2):
        q = movingAver(q)
    return asarray(q)

def movingAver(p):
    """Apply moving average smoothing on points p"""
    for j in range(1, len(p)-1):
        p[j, 1] = (p[j-1, 1]+p[j, 1]+p[j+1, 1])/3.
    return p

def lowpass(self,lambda1=1.02,mu1=-0.8,n=1):
    """Smoothen the model"""
    new = self.copy()
    new1 = self.copy()
    for j in range(n):
        for i in range(1,len(new)-1):
            new1[i] = new[i]+lambda1*0.5*(new[i-1]-new[i]+new[i+1]-new[i])
        for i in range(1,len(new)-1):
            new[i] = new1[i]+mu1*0.5*(new1[i-1]-new1[i]+new1[i+1]-new1[i])
    return new

def selectFile(ext='Point file (*.csv)'):
    """Selects a file."""
    global fn
    fn = askFilename(fn,[ext,'All Files (*)'],multi=False,exist=True)
    if fn:
        currentDialog().updateData({'fn':fn})
        message('Selected file: '+fn)
    else:
        message('No new file selected')

def rotateVectorOn(v1, v2):
    """Calculate the angle (in degrees) and rotation vector to get v1 onto v2"""
    rotationvector = cross(v1, v2)
    rotationangle = vectorPairAngle(v1,v2)*180./pi
    return rotationangle, rotationvector

###Definition to create the geometry###_______________________________________________________________________________________________

def fill(P):
    """This function constructs the fish mouth model based on the given basepoints (P has to be an 10x3 array!)"""
    PropNr = {'skullRoof': 1, 'snout': 1, 'gillCover': 2, 'lowerJaw': 3, 'cheekBone': 4, 'hyoid': 5, 'backSide': 6, 'mouth': 8}
    [P1,P2,P3,P4,P5,P6,P9,P10,P11] = P

    #########SKULLROOF#########
    P0 = Coords([P1[0], 0., 0.])
    P12 = Coords([P2[0], 0., 0.])
    skullRoof = createQuad([P0,P1,P2,P12])
    skullRoof.setProp(PropNr['skullRoof'])
    #draw(skullRoof)

    #########CHEEKBONE#########
    cheekBone = createQuad([P1,P5,P4,P11])+createTri([P1,P11,P2])
    cheekBone.setProp(PropNr['cheekBone'])
    #draw(cheekBone)

    #########GILLCOVER#########
    gillCover = createTri([P6,P5,P1])
    gillCover.setProp(PropNr['gillCover'])
    #draw(gillCover)

    #########BACKSIDE#########
    P13 = Coords([P6[0], P6[1], 0.])
    P14 = Coords([P5[0], P5[1], 0.])
    backSide = createQuad([P13,P6,P1,P0]) + createQuad([P5,P6,P13,P14])
    backSide.setProp(PropNr['backSide'])
    #draw(backSide)

    #########SNOUT#########
    ndiv = 8
    R1 = Coords([P2+i/float(ndiv)*(P12-P2) for i in range(ndiv+1)])
    a,b = P2[0]-P3[0],P2[2]
    S1 = Coords([[i[0]-sqrt(1.-i[2]**2/b**2)*a,i[1],i[2]] for i in R1])
    snout = Formex([[S1[i+1],R1[i+1],R1[i]] for i in range(ndiv)])+Formex([[S1[i],S1[i+1],R1[i]] for i in range(1,ndiv)])
    snout.setProp(PropNr['snout'])
    #draw(snout)

    #########LOWERJAW#########
    P15 = Coords([P11[0], P11[1], 0.])
    R2 = Coords([P11+i/float(ndiv)*(P15-P11) for i in range(ndiv+1)])
    a,b = distance(P15,P10),P11[2]
    S2 = Coords([[i[0]-sqrt(1-i[2]**2/b**2)*a,P11[1],i[2]] for i in R2]).rotate(axis=2,angle=arctan((P10[1]-P11[1])/(P10[0]-P11[0]))*180./pi,around=P11)
    lowerJaw = Formex([[S2[i+1],S2[i],P9] for i in range(0,ndiv)])+createTri([P5,P9,P4])+createTri([P4,P9,P11])
    lowerJaw.setProp(PropNr['lowerJaw'])
    #draw(lowerJaw)

    #########MOUTH#########
    mouth = Formex([[S2[i],S2[i+1],S1[i]] for i in range(ndiv)])+Formex([[S2[i+1],S1[i+1],S1[i]] for i in range(ndiv)])
    mouth.setProp(PropNr['mouth'])
    area = 2*sum(TriSurface(mouth).area())
    #draw(mouth)

    #########HYOID#########
    P16 = Coords([P5[0], P5[1], 0.])
    hyoid = createTri([P16,P9,P5])
    hyoid.setProp(PropNr['hyoid'])
    #draw(hyoid)

    #########COMPLETE MODEL#########
    full = skullRoof + cheekBone + gillCover + backSide + snout + lowerJaw + mouth + hyoid
    full = full.reverse()
    full += full.reflect(2).reverse()
    #draw(full)

    P7 = -P1
    P8 = Coords([P2[0],P2[1],-P2[2]])
    P = Coords([P0,P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15])

    return full,P,area


###Dialog###___________________________________________________________________________________________________________________________________________

dialog = None

_menu = 'Suction model'

def create_menu():
    """Create the menu"""
    MenuData = [
    ("&Create suction model",suction),
    ("&Draw model",drawmodel),
    ("&Select model",selection.ask),
    ("&Select tool",formex_menu.selection.ask),
    ("&Rename model",rename),
    ("&Write model",writemodel),
    ("&Write reference points",writereferencepoints),
    ("---",None),
    ("&Rotate",rotate),
    ("&Rotate over interval",rotateinterval),
    ("&Rotate over two parameters",rotatetwo),
    ("&Rotate over three parameters",rotatethree),
    ("&Rotate according to file", rotatefile),
    ("---",None),
    ("Flow speed",flowspeed),
    ("---",None),
    ("&Calculate volume",calculatevolume),
    ("&Calculate mouth aperture area",openarea),
    ("&Calculate gape distance",gapeDist),
    ("&Manually edit the model points",setbasepoints),
    ("&Extract basepoints from the current model",extractbasepoints),
    ("---",None),
    ("&Show current basepoints",showbasepoints),
    ("&Check current basepoints",checkbasepoints),
    ("&Show csv reference points",showcsvpoints),
    ("&Show model dimensions",showsize),
    ("&Show bounding box",showbbox),
    ("&Show axes",showaxes),
    ("&Show point coordinates",showcoords),
    ("&Show distance",showdistance),
    ("&Show angle",showangle),
    ("&Draw lines",drawlines),
    ("---",None),
    ("&Reload Menu",reload_menu),
    ("&Close Menu",close_menu)
    ]
    return menu.Menu(_menu,items=MenuData,parent=pf.GUI.menu,before='help')

def show_menu():
    """Show the menu."""
    if not pf.GUI.menu.item(_menu):
        create_menu()
        message('Suction menu loaded')

def close_menu():
    """Close the menu."""
    m = pf.GUI.menu.item(_menu)
    if m :
        m.remove()

def reload_menu():
    """Reload the menu."""
    close_menu()
    show_menu()

###Starting actions###_____________________________________________________________________________________________________________________________
if __name__ == 'draw':
    chdir(__file__)
    clear()
    reset()
    layout(nvps=1)
    bgcolor('white')
    toolbar.setProjection()
    global basepoints                           #Global variable containing the points on which the model is build
    basepoints = ndarray([0,0]).astype(float)
    global fn                                   #Global filename
    global res
    reload_menu()
    suction()
    message("Geometry created")
    message("Generate results based on kinematic data")
    rotatefile()

if __name__ == '__main__':
    print('This script should be executed from pyFormex (see pyformex.org)')

# End
