.. pyFormex Suction Menu

..
  Copyright (C) 2013
  Tomas Praet (tomas.praet@telenet.be),
  Benedict Verhegghe (benedict.verhegghe@ugent.be),
  Anabela Maia (anabelamaia@gmail.com),
  Dominique Adriaens (dominique.adriaens@ugent.be),

  Distributed under the GNU General Public License version 3 or later.

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see http://www.gnu.org/licenses/.


============
Suction Menu
============

This is a plugin menu for pyFormex. It was developed on pyFormex 0.8.6.

Besides the normal pyFormex installation, you also need SciPy.
Debian users::

  apt-get install python-scipy

This script generates a geometric model of the shape of a fish head.
The model is parametric and can be adapted to the species by the position
of ten reference points, which can for example be obtained from measurements
on CT scans. An example of input points can be found in the file
input/examplePoints.csv.

Kinematic data can be read in from a text file (see example input/example.csv),
and volume changes of the fish head can then be calculated. From these the
the feeding performance of the fish species can be evaluated.

The result is a csv file that can be read into a spreadsheet program for
further evaluation.

.. End
